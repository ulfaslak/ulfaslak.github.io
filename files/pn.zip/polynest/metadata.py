# -*- coding: utf-8 -*-
"""
Package matadata.
"""

__version__ = "0.0.1"
__author__ = "Ulf Aslak"
__copyright__ = "Copyright 2021, Rodinia Generation"
__credits__ = ["Ulf Aslak"]
__license__ = None
__maintainer__ = "Ulf Aslak"
__email__ = "ulf@rodiniageneration.io"
__status__ = "Development"
