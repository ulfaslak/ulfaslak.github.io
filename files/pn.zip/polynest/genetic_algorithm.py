# -*- coding: utf-8 -*-
"""
This module provides key utility functions that support the genetic algorithm.
These functions are placed outside of the `Nest` class because they do not depend
on the state of the algorithm.
"""

from collections import defaultdict
import numpy as np

from polynest import utils


def mate(pair_and_params):
    """Compute mutated children of pair.

    Parameters
    ----------
        pair_and_params : tuple of dicts

    Returns
    -------
        out : list of dicts
    """
    father, mother, params = pair_and_params
    boy, girl = cross_breed([father, mother])
    return [mutate(boy, params), mutate(girl, params)]


def mutate(specimen, params):
    """Randomize order and rotation of parts for a specimen.

    Swap parts that have the same order index. Then swap groups of parts that
    have different order indices.

    Parameters
    ----------
        specimen : list of dicts (same structure as `placement_order`)
        params : dict

    Returns
    -------
        mutant : list of dicts
    """

    def __swap_parts_with_same_order_index(order, rotation):
        """Swap parts that have same order index.

        This method also returns a `swapped_order_indices` dictionary,
        which tracks every pair of order indices that should be swapped
        inside `__swap_parts_with_different_order_index`.

        Parameters
        ----------
            order : list of tuples
            rotation : list of ints

        Returns
        -------
            order : list of tuples
            rotation : list of ints
            swapped_order_indices : dict
                Map of which order indices that get swapped in `__swap_parts_with_different_order_index`.
        """
        swapped_order_indices = dict()
        for i in range(len(order) - 1):

            if utils.random_float(params["seed"], i) < params["GA_mutation_rate"]:

                # Parts to swap
                part_a = order[i]
                part_b = order[i + 1]
                a_order_ind = params["order_indices"][part_a[0]]
                b_order_ind = params["order_indices"][part_b[0]]

                # Rotations to swap
                theta_a = rotation[i]
                theta_b = rotation[i + 1]

                if a_order_ind == b_order_ind:
                    if not params["group_copies"] or (
                        params["group_copies"] and part_a[1] == part_b[1]
                    ):
                        # Swap
                        order[i] = part_b
                        order[i + 1] = part_a
                        rotation[i] = theta_b
                        rotation[i + 1] = theta_a

                # If neither order indices have been swapped
                elif len(set(swapped_order_indices) & {a_order_ind, b_order_ind}) == 0:

                    swapped_order_indices[a_order_ind] = b_order_ind
                    swapped_order_indices[b_order_ind] = a_order_ind

        return order, rotation, swapped_order_indices

    def __swap_parts_with_different_order_index(order, rotation, swapped_order_indices):
        """Swap polygons that have different order index.

        Parameters
        ----------
            order : list of tuples
            rotation : list of ints
            swapped_order_indices : dict

        Returns
        -------
            order : list of tuples
            rotation : list of ints
        """
        reordered_segments = defaultdict(lambda: defaultdict(list))
        for i, part in enumerate(order):
            theta = rotation[i]
            order_ind = params["order_indices"][part[0]]
            if order_ind in swapped_order_indices:
                new_order_ind = swapped_order_indices[order_ind]
                reordered_segments[new_order_ind]["order"].append(part)
                reordered_segments[new_order_ind]["rotation"].append(theta)
            else:
                reordered_segments[order_ind]["order"].append(part)
                reordered_segments[order_ind]["rotation"].append(theta)

        order, rotation = [], []
        for order_ind in sorted(reordered_segments):
            order.extend(reordered_segments[order_ind]["order"])
            rotation.extend(reordered_segments[order_ind]["rotation"])

        return order, rotation

    # Instantiate mutant and indices for order index swapping
    order = specimen["order"][:]
    rotation = specimen["rotation"][:]

    # Randomize order of polygons with same order index
    order, rotation, swapped_order_indices = __swap_parts_with_same_order_index(order, rotation)

    # Randomize order indices
    if params["allow_order_swaps"]:
        order, rotation = __swap_parts_with_different_order_index(
            order, rotation, swapped_order_indices
        )

    # Randomize rotations
    rotation = [
        utils.random_angle(params["num_rotations"])
        if np.random.random() < params["GA_mutation_rate"]
        else theta
        for theta in rotation
    ]

    return dict(order=order, rotation=rotation)


def cross_breed(pair, cross_point=None):
    """Take two lists and create a mix of them, at a given point.

    Parameters
    ----------
        pair : list of dicts
        cross_point : float (between 0 and 1)

    Returns
    -------
        children : list of dicts
    """
    if cross_point is None:
        cross_point = np.random.random() * 0.8 + 0.1
    cross_index = int(cross_point * len(pair[0]["order"]))

    father, mother = pair

    # Initiate children
    boy = dict(
        order=father["order"][:cross_index],
        rotation=father["rotation"][:cross_index],
    )
    girl = dict(
        order=mother["order"][:cross_index],
        rotation=mother["rotation"][:cross_index],
    )

    for i, part in enumerate(mother["order"]):
        if part not in boy["order"]:
            boy["order"].append(part)
            boy["rotation"].append(mother["rotation"][i])

    for i, part in enumerate(father["order"]):
        if part not in girl["order"]:
            girl["order"].append(part)
            girl["rotation"].append(father["rotation"][i])

    return [boy, girl]
