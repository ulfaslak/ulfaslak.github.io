# -*- coding: utf-8 -*-
"""
Fast polygon packing in Python.
"""

from _polynest import *

from .metadata import __version__
from .models import *
