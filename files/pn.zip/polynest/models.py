# -*- coding: utf-8 -*-
"""
This module provides model classes for nesting. `Nest` is an abstract base class
that other nesting models inherit from. It implements the basic initialization that
must run after model input has been provided, as well as the genetic algoritm iteration.
Each subclass of `Nest`, e.g. `NestRectangular´ implements methods to place polygons,
generate translations and fit.
"""

from abc import ABC
import warnings
import functools
from multiprocessing import get_context
import numpy as np
from pyclipper import scale_to_clipper as to_clipper
from pyclipper import scale_from_clipper as from_clipper

from polynest import utils
from polynest import genetic_algorithm as ga
import _polynest as _utils


class Nest(ABC):
    """Abstract base class for nesting.

    Contains all method implementations that are reused across nesting classes,
    as well as abstract classes for methods that must be declared in a class.
    """

    # pylint: disable=maybe-no-member

    # @abstractmethod
    # def place_polygons(self):
    #     pass

    # @abstractmethod
    # def generate_translation(self):
    #     pass

    # -----------------
    # Universal methods
    # -----------------

    def __init__(self):
        # Initialize paramters created by `init_conditions`
        self.polygons = None
        self.bin = None
        self.order_indices = None
        self.quantity = None
        self.n_polygons = None
        self.polygon_set = None
        self.index_map = None
        self.best_placement_order = None
        self.population = None

    def init_conditions(self, polygons, bin, order_indices, quantity):
        """Initialization function run by every fitting method.

        * Creates all necessary class attributes
        * Processes inputted polygons (set matching, offsetting, winding)
        * Initializes a placement order
        * Computes NFPs for the cache.
        """
        # Input variables
        self.polygons = self.__assert_and_format_polygons(polygons)
        self.bin = self.__assert_and_format_bin(bin)
        self.order_indices = self.__assert_and_format_order_indices(order_indices)
        self.quantity = self.__assert_and_format_quantity(quantity)

        # Unique polygons ...
        self.n_polygons = sum(quantity) if quantity else len(polygons)
        self.polygon_set, self.index_map = utils.get_polygon_set(polygons, self.params)

        # Optimization parameters
        self.best_placement_order = self.__init_placement_order()

        # Genetic algorithm population
        self.population = self.__first_generation(self.best_placement_order)

        # Initialize polygon and NFP caches (compute the initially necessary)
        self.__fill_polygon_cache(self.population)
        self.__fill_nfp_cache(self.population, self.num_procs)

    def compute_efficiency(self):
        """Get the packing effiency (1 - waste), of a nesting."""
        total_area = sum(self.quantity[i] * data["area"] for i, data in self.index_map.items())
        width = self.bin[0] if self.params["gravity_direction"] in ["up", "down"] else self.bin[1]
        return total_area / sum(width * length for length in self.bin_costs)

    def __init_placement_order(self):
        """Initial polygon sorting before translation optimization.

        Sorts polygons by size given order constraints.

        Returns
        -------
            out : list of tuples
        """

        def __sort_func(i, j):
            if not self.order_indices or self.order_indices[i] == self.order_indices[j]:
                area_i, area_j = self.index_map[i]["area"], self.index_map[j]["area"]
                return area_j - area_i
            return self.order_indices[i] - self.order_indices[j]

        if not self.params["group_copies"]:
            # Reorder by area and `order_indices`
            order = list(range(len(self.polygons)))
            order.sort(key=functools.cmp_to_key(__sort_func))
            return dict(
                order=[(i, c) for i in order for c in range(self.quantity[i])],
                rotation=[self.__randrot(i) for i in range(self.n_polygons)],
            )
        else:
            out = dict(
                order=[],
                rotation=[self.__randrot(i) for i in range(self.n_polygons)],
            )

            # I create a vectorized `order_indices`, so that I can get the polygon
            # indices that correspond to a given order index.
            order_indices_arr = np.array(self.order_indices)

            # Then I loop through a list of unique order indices. If the original
            # order indices are [0, 0, 0, 0, 1, 1], then I will simply loop through
            # [0, 1].
            for order_index in sorted(set(self.order_indices)):

                # I get all the polygon indices that have this order_index.
                indices_with_order_index = np.where(order_indices_arr == order_index)[0]

                # Then, I create a temporary list of quantities for polygons with
                # that order index. This is a list I can deduct from each time I put
                # a polygon reference into the 'out' list, keeping track of how many
                # of which polygons have been added.
                quantity_order_index = list(np.array(self.quantity)[indices_with_order_index])

                # Also, create a list to keep track of how many copies have been appended.
                quantity_order_index_inv = [0 for _ in quantity_order_index]

                # I then loop over the polygon indices with the given order, until the
                # `quantity_order_index` list sums to 0, at which point I will have
                # appended all polygon references.
                i = 0
                while sum(quantity_order_index) > 0:
                    c = quantity_order_index_inv[i]
                    if quantity_order_index[i] > 0:
                        out["order"].append((indices_with_order_index[i], c))
                        quantity_order_index[i] -= 1
                        quantity_order_index_inv[i] += 1
                    i += 1
                    i %= len(quantity_order_index)
            return out

    def __fill_polygon_cache(self, placement_order_list):
        """Storing all the unique polygons that result from rotations.

        Parameters
        ----------
            placement_order_list : list of lists of dicts
        """
        # Bin polygon
        if (-1, 0) not in self.polygon_cache:
            self.polygon_cache[(-1, 0)] = np.array(utils.create_bin_polygon(self.bin))

        # Rotated polygons
        for placement_order in placement_order_list:
            order = placement_order["order"]
            rotation = placement_order["rotation"]
            for i, part in enumerate(order):
                iu = self.index_map[part[0]]["u"]
                r = rotation[i]
                key_iur = (iu, r)
                if key_iur not in self.polygon_cache:
                    self.polygon_cache[key_iur] = np.array(
                        _utils.rotate_polygon(self.polygon_set[iu], r, True)
                    )

    def __fill_nfp_cache(self, placement_order_list, num_procs):
        """Compute backwards compared NFP pairs for placed parts.

        For each peace `i` in placement order, compute the NFPs of it against
        all other placed polygons `j`.

        Parameters
        ----------
            placement_order_list : list of list of dicts
        """
        # Get new NFP pairs
        new_nfp_pairs = dict()
        for placement_order in placement_order_list:
            order = placement_order["order"]
            rotation = placement_order["rotation"]
            for i, part_i in enumerate(order):
                iu = self.index_map[part_i[0]]["u"]

                # Polygon against bin
                key_pair = ((-1, 0), (iu, rotation[i]))
                if key_pair not in self.nfp_cache:
                    new_nfp_pairs[key_pair] = (
                        self.polygon_cache[key_pair[0]],
                        self.polygon_cache[key_pair[1]],
                    )

                # Polygon against placed polygons
                for j, part_j in enumerate(order[:i]):
                    ju = self.index_map[part_j[0]]["u"]
                    key_pair = ((ju, rotation[j]), (iu, rotation[i]))
                    if key_pair not in self.nfp_cache:
                        new_nfp_pairs[key_pair] = (
                            self.polygon_cache[key_pair[0]],
                            self.polygon_cache[key_pair[1]],
                        )

        # Parallelization
        if num_procs and num_procs > 1:
            with get_context("fork").Pool(num_procs) as p:
                for key_pair, nfp in p.map(utils.minkowski_diff, new_nfp_pairs.items()):
                    self.nfp_cache[key_pair] = nfp
        else:
            for key_pair, nfp in map(utils.minkowski_diff, new_nfp_pairs.items()):
                self.nfp_cache[key_pair] = nfp

    def __randrot(self, k=0):
        utils.seed_rng(self.seed, k)
        return np.random.randint(self.params["num_rotations"]) * 360 / self.params["num_rotations"]

    # -----------------
    # Genetic algorithm
    # -----------------

    def iterate(self):
        """Execute an iteration of the genetic algorithm.

        (1) Compute cost for each specimen, (2) create new population that selectively
        breeds the best specimen (3) refill caches, (4) return best specimen.
        """

        # (1)
        result = self.__compute_translations()
        bin_cost_scores = list(zip(*result))[1]
        cost_scores = [sum(costs) for costs in bin_cost_scores]

        # (2)
        self.population = self.__new_generation(cost_scores)

        # (3)
        self.__fill_polygon_cache(self.population)
        self.__fill_nfp_cache(self.population, self.num_procs)

        # (4)
        i_opt = cost_scores.index(min(cost_scores))
        return self.population[i_opt], result[i_opt]

    def __compute_translations(self):
        """For order and rotation in population, compute translations and cost.

        Simply:
        >>> result[0] == zip(translations, cost)

        Returns
        -------
            result : list of dicts of list of dicts and float
        """
        if self.num_procs and self.num_procs > 1:
            with get_context("fork").Pool(self.num_procs) as p:
                return list(p.map(self.place_polygons, self.population))
        else:
            return list(map(self.place_polygons, self.population))

    def __first_generation(self, specimen):
        """Create population of mutants of `specimen`.

        Parameters
        ----------
            specimen : list of dicts

        Returns
        -------
            population : list of lists of dicts
        """
        population = [specimen]
        for _ in range(self.params["GA_population_size"] - 1):
            params = dict(
                seed=self.seed,
                GA_mutation_rate=self.params["GA_mutation_rate"],
                order_indices=self.order_indices,
                allow_order_swaps=self.params["allow_order_swaps"],
                group_copies=self.params["group_copies"],
                num_rotations=self.params["num_rotations"],
            )
            population.append(ga.mutate(population[0], params))
        return population

    def __new_generation(self, cost_scores):
        """Create population of mutated children of stochastically
        drawn best specimen.

        Parameters
        ----------
            cost_scores : list

        Returns
        -------
            population : lists of dicts
        """

        def inv(x):
            """Transform array of values to a probability distribution where small
            values are more likely than large values.
            """
            if min(x) == max(x):
                return x
            x = 1 / x
            x -= min(x)
            x /= max(x)
            x **= self.params["GA_proba_dist_exponent"]
            x += 1e-4
            return x

        # Sort `self.population` and `cost_scores` wrt `cost_scores`
        population, cost_scores = utils.sort_lists_wrt_one([self.population, cost_scores], 1)

        mate_params = dict(
            seed=self.seed,
            GA_mutation_rate=self.params["GA_mutation_rate"],
            order_indices=self.order_indices,
            allow_order_swaps=self.params["allow_order_swaps"],
            group_copies=self.params["group_copies"],
            num_rotations=self.params["num_rotations"],
        )

        pairs_and_params = [
            utils.get_random_pair(population, cost_scores, inv) + (mate_params,)
            for _ in range(self.params["GA_population_size"] // 2)
        ]

        if self.num_procs and self.num_procs > 1:
            with get_context("fork").Pool(self.num_procs) as p:
                children_arr = p.map(ga.mate, pairs_and_params)
        else:
            children_arr = map(ga.mate, pairs_and_params)

        # Start new population with best specimen
        new_population = [population[0]]
        for children in children_arr:
            new_population.append(children[0])
            if len(new_population) < self.params["GA_population_size"]:
                new_population.append(children[1])

        return new_population

    # ----------
    # Assertions
    # ----------

    def __assert_and_format_polygons(self, polygons):
        def list_depth(arr):
            def is_list(inner_arr):
                return type(inner_arr) in [list, tuple] and len(arr) > 0

            return is_list(arr) and (max(map(list_depth, arr)) + 1) if str(arr) else 1

        assert isinstance(polygons, list), "`polygons` must be of type `list`."
        assert list_depth(polygons) == 3, "each element of `polygons` must be a list of lists."
        return polygons

    def __assert_and_format_bin(self, bin):
        assert isinstance(bin, tuple), "`bin` must be of type `tuple`."
        assert len(bin) == 2, "`bin` must have dimensions `(width, height)`."
        assert min(bin) > 0, "all values of `bin` must be greater than 0."
        bin = (bin[0] * self.params['dpm'], bin[1] * self.params['dpm'])
        return bin

    def __assert_and_format_order_indices(self, order_indices):
        if order_indices is None:
            return [0 for _ in self.polygons]
        assert isinstance(order_indices, list), "`order_indices` must be of type `list`."
        assert len(order_indices) == len(
            self.polygons
        ), "`order_indices` must have same length as `polygons`."
        return order_indices

    def __assert_and_format_quantity(self, quantity):
        if quantity is not None:
            assert isinstance(quantity, list), "`quantity` must be of type `list`."
            assert len(quantity) == len(
                self.polygons
            ), "`quantity` must have same length as `polygons`."
            assert min(quantity) > 0, "all values of `quantity` must be greater than 0."
        else:
            quantity = [1 for _ in self.polygons]
        return quantity


class NestRectangular(Nest):
    """Nest polygons in bin(s).

    Parameters
    ----------
        add_bin_on_overflow : boolean, optional
        gravity_direction : {'left', 'right', 'up', 'down'}, optional
        allow_order_swaps : bool, optional
        group_copies : bool, optional
        part_spacing : float, optional
        num_rotations : int, optional
        dpm : float, optional
        curve_tolerance : float, optional
        merge_similarity_threshold : float, optional
        GA_population_size : int, optional
        GA_mutation_rate : float, optional
        GA_proba_dist_exponent : float, optional
        num_procs : int
        seed : int
        verbose : bool

    Example 1
    ---------
        >>> polygons = [
                [(0, 0), (0, 1), ...],
                ...
            ]
        >>> bin = (8000, 2000)

        >>> nest = NestRectangular()
        >>> nest.fit(polygons, bin, patience=10)

        >>> translations = nest.translations

        >>> # `placement[i]` is used to translate `polygon[i]`
        >>> len(translations) == len(polygons)
        True

    Example 2
    ---------
        >>> nest = NestRectangular()
        >>> nest_iter = nest.generate_translations(polygons, bin)

        >>> translations = None
        >>> min_cost = np.inf
        >>> for _ in range(100):
        >>>     translations, cost = next(nest_iter)
        >>>     if cost < min_cost
        >>>         translations = translations
    """

    def __init__(
        self,
        add_bin_on_overflow=True,
        gravity_direction="left",
        allow_order_swaps=False,
        group_copies=False,
        part_spacing=0,
        num_rotations=1,
        dpm=2834.6456664,
        curve_tolerance=0.03,
        merge_similarity_threshold=0.999,
        GA_population_size=10,
        GA_mutation_rate=0.1,
        GA_patience=5,
        GA_proba_dist_exponent=1,
        num_procs=None,
        seed=None,
        verbose=False,
    ):
        # Initialize hyperparameters
        self.params = dict(
            add_bin_on_overflow=add_bin_on_overflow,
            gravity_direction=gravity_direction,
            allow_order_swaps=allow_order_swaps,
            group_copies=group_copies,
            part_spacing=part_spacing,
            num_rotations=num_rotations,
            dpm=dpm if (dpm or 0) > 1 else 1,
            curve_tolerance=curve_tolerance,
            merge_similarity_threshold=merge_similarity_threshold,
            GA_population_size=GA_population_size,
            GA_mutation_rate=GA_mutation_rate,
            GA_patience=GA_patience,
            GA_proba_dist_exponent=GA_proba_dist_exponent,
            num_procs=num_procs,
            seed=seed,
            verbose=verbose,
        )

        # Initialize run parameters
        self.num_procs = num_procs
        self.seed = seed
        self.verbose = verbose

        # Initialize state variables
        self.iterations = 0
        self.initialized = False
        self.polygon_cache = {}
        self.nfp_cache = {}
        self.best_translations = None
        self.min_cost = np.inf
        self.best_efficiency = None

        # Initialize input parameters
        self.polygons = None
        self.bin = None
        self.order_indices = None
        self.quantity = None
        self.n_polygons = None
        self.polygon_set = None
        self.index_map = None
        self.best_placement_order = None
        self.worst_placement_order = None
        self.population = None

        # Tracking
        self.best_iteration = 0

    def fit(self, polygons, bin, order_indices=None, quantity=None):
        """Main method that the user calls. Runs any number of iterations of the
        `generate_translations` generator until patience runs out.

        Parameters
        ----------
            polygons : list of lists of dicts
            bin : tuple
            order_indices : list of ints, optional
            quantity : list of ints, optional
        """
        if not self.initialized:
            self.init_conditions(polygons, bin, order_indices, quantity)
            self.initialized = True

        patience_counter = 0
        while patience_counter < self.params["GA_patience"]:

            placement_order, (translations, bin_costs) = self.iterate()
            cost = sum(bin_costs)

            if cost < self.min_cost:
                self.best_placement_order = placement_order
                self.best_translations = translations
                self.min_cost = cost
                self.bin_costs = bin_costs
                self.best_iteration = self.iterations
                self.best_efficiency = self.compute_efficiency()
                patience_counter = 0
            else:
                patience_counter += 1

            if self.verbose:
                print(
                    f"Iter: {self.iterations}" + " " * (4 - len(str(self.iterations))) + "| "
                    f"Patience: {patience_counter}" + " " * (4 - len(str(patience_counter))) + "| "
                    f"Cost: {(cost / self.params['dpm']):.3f}" + f"{' m' if self.params['dpm'] > 1 else ''}" + " | "
                    f"Efficiency: {self.best_efficiency:.3f}",
                )

            self.iterations += 1

    def fit_iterator(self, polygons, bin, order_indices=None, quantity=None):
        """Runs like `fit` above, but yields each iteration.

        Parameters
        ----------
            polygons : list of lists of dicts
            bin : tuple
            order_indices : list of ints, optional
            quantity : list of ints, optional
        """
        if not self.initialized:
            self.init_conditions(polygons, bin, order_indices, quantity)
            self.initialized = True

        patience_counter = 0
        while patience_counter < self.params["GA_patience"]:

            placement_order, (translations, bin_costs) = self.iterate()
            cost = sum(bin_costs)

            if cost < self.min_cost:
                self.best_placement_order = placement_order
                self.best_translations = translations
                self.min_cost = cost
                self.bin_costs = bin_costs
                self.best_iteration = self.iterations
                self.best_efficiency = self.compute_efficiency()
                patience_counter = 0
            else:
                patience_counter += 1

            if self.verbose:
                print(
                    f"Iter: {self.iterations}" + " " * (4 - len(str(self.iterations))) + "| "
                    f"Patience: {patience_counter}" + " " * (4 - len(str(patience_counter))) + "| "
                    f"Cost: {cost:.3f}" + "| "
                    f"Efficiency: {self.best_efficiency:.3f}",
                )

            yield self

            self.iterations += 1

    def generate_translations(self, polygons=None, bin=None, order_indices=None, quantity=None):
        """Produce nesting placements of polygons in bin(s).

        Used seperately in a loop that should be broken upon some condition.

        Parameters
        ----------
            polygons : list of lists of dicts
            bin : tuple
            order_indices : list of ints, optional
            quantity : list of ints, optional

        Yields
        ------
            placement_order, (translations, cost)
        """
        if not self.initialized and None not in [polygons, bin]:
            self.init_conditions(polygons, bin, order_indices, quantity)
            self.initialized = True

        while True:
            self.iterations += 1
            yield self.iterate()

    def place_polygons(self, placement_order):
        """Nest `self.polygons` in `bin`, following the `placement_order`.

        Parameters
        ----------
            placement_order : dict
                placement_order['order'] : list of (`id`, `copy_id`)

        Returns
        -------
            translations : list of dicts
            cost : float
        """
        order = placement_order["order"]
        rotation = placement_order["rotation"]

        translations = []
        bin_costs = [0]
        
        bin_i = 0
        bin_i_max = 0
        valid_positions = []

        while len(translations) < len(order):

            # These are all the indices and key variables that gets consumed in this
            # iteration. `key_iur` represents the part's geometry, given rotation) 
            # and is used to generate nfps.
            ind = len(translations)
            part = order[ind]  # tuple `("index", "copy index")`
            iu = self.index_map[part[0]]["u"]
            r = rotation[ind]
            key_iur = (iu, r)
            bin_nfp = self.nfp_cache[((-1, 0), key_iur)]

            # If `valid_positions` is `[]` at this point, it is either the very first
            # iteration, OR the previous iteration had a full bin. In either case, the
            # list of valid positions will == the `bin_nfp`.
            if len(valid_positions) == 0:
                valid_positions = bin_nfp

            # If there exists `valid_positions` a part was successfully placed in a bin
            # in the previous iteration. To continue, (1) combine nfps of placed parts with
            # current part, and (2) subtract it from bin nfp to get valid positions for
            # the part.
            else:
                # Since this is not the first part in the bin, it is possible that there it
                # is small enough to fit inside one of the "full" bins. Try each previous bin.
                bin_i = 0
                while bin_i <= bin_i_max:
                    # Collect the list of all nfps for `part` on existing part in `bin_i`.
                    nfps = [
                        self.nfp_cache[(t["key"], key_iur)] + t["d_clipper"]
                        for t in translations
                        if t["bin_i"] == bin_i
                    ]

                    # But probably, there was space, and we can proceed to get the union polygon of
                    # the existing nfps, and subtract the `bin_nfp` from that to get the valid positions.
                    union_nfp = utils.polygon_union(nfps)
                    valid_positions = utils.polygon_set_difference(union_nfp, [bin_nfp])
                    valid_positions = np.array(utils.flatten(valid_positions))

                    # Break the loop when valid positions are found. Increment the `bin_i` otherwise.
                    if len(valid_positions) > 0:
                        break
                    else:
                        bin_i += 1

            # If no valid positions are found, all the bins were full and a new one must be opened
            # (or a warning must get triggered if `add_bin_on_overflow == False`). 
            if len(valid_positions) == 0:
                
                # If this it the first part, the bin is too small!
                if ind == 0:
                    raise Exception("Bin too small for first part.")  # TODO: Check that this triggers correctly
                
                # Handle creation of new bin                
                if self.params["add_bin_on_overflow"]:
                    bin_costs.append(0)
                    bin_i_max = bin_i
                    continue

                # If only a single bin is desired, warn the user that the bin space was exceed and return.    
                else:
                    warnings.warn(
                        f"Bin space exceeded. {self.n_polygons - 1 - ind} polygons "
                        "could not be placed. Returning successful placements."
                    )
                    cost = (
                        self.bin[0]
                        if self.params["gravity_direction"] in ["left", "right"]
                        else self.bin[1]
                    )
                    return translations, [cost]
            
            # If valid positions are found, take the best one, and compute part translation and update
            # the bin cost.
            else: 
                # Get best position
                best_position = utils.plane_min(valid_positions, self.params["gravity_direction"])

                # Convert to displacements
                d = list(
                    np.array(from_clipper(best_position))
                    - _utils.rotate_point(
                        np.array(self.polygons[part[0]][0]) - self.index_map[part[0]]["d_anchor"], r
                    )
                )
                d_clipper = best_position - self.polygon_cache[key_iur][0]

                translations.append(
                    dict(
                        d=d, d_clipper=list(d_clipper), i=part[0], iu=iu, key=key_iur, r=r, bin_i=bin_i
                    )
                )

                # Evaluate cost
                length = utils.plane_length(
                    np.array(from_clipper(self.polygon_cache[key_iur] + d_clipper)),
                    self.params["gravity_direction"],
                    self.bin,
                )

                if length > bin_costs[bin_i]:
                    bin_costs[bin_i] = length

        return translations, bin_costs
