# -*- coding: utf-8 -*-
"""
This module provides simple plotting tools for nesting solutions.
"""

import matplotlib.pylab as plt
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection
import numpy as np

import _polynest as _utils


def plot_polygon(points, **kwargs):
    """Plot set of points as polygon.

    Input
    -----
        points : array-like (N, 2)
        **kwargs : valid keyword-arguments
    """
    plt.gca().add_collection(PatchCollection([Polygon(points, True)], **kwargs))


def plot_nesting(nest, translations=None, frame_width=15, **plotting_kwargs):
    """Plot nesting.

    Input
    -----
        nest : `Nest` object.
        translations : list of dicts
        frame_width : number
    """

    def _plot_single_nesting(width, height, bin_i, frame_width):
        plt.figure(figsize=(frame_width, frame_width * height / width))
        for t in translations:
            if t["bin_i"] == bin_i:
                plot_polygon(
                    np.array(_utils.rotate_polygon(nest.polygons[t["i"]], t["r"], False)) + t["d"],
                    **plotting_kwargs
                )
        if nest.params["gravity_direction"] == "left":
            plt.xlim(0, nest.bin_costs[bin_i])
            plt.ylim(0, height)
        if nest.params["gravity_direction"] == "right":
            plt.xlim(nest.bin[0] - nest.bin_costs[bin_i], nest.bin[0])
            plt.ylim(0, height)
        if nest.params["gravity_direction"] == "down":
            plt.ylim(0, nest.bin_costs[bin_i])
            plt.xlim(0, nest.bin[0])
        if nest.params["gravity_direction"] == "up":
            plt.ylim(nest.bin[1] - nest.bin_costs[bin_i], nest.bin[1])
            plt.xlim(0, nest.bin[0])

    # Load best translations if none are provided
    if translations is None:
        translations = nest.best_translations

    # Sort out the plotted pixel dimensions (only plot where we nest)
    if nest.params["gravity_direction"] in ["left", "right"]:
        widths = nest.bin_costs
        height = nest.bin[1]
        for bin_i, width in enumerate(widths):
            _plot_single_nesting(width, height, bin_i, frame_width * width / max(widths))
    else:
        width = nest.bin[0]
        heights = nest.bin_costs
        for bin_i, height in enumerate(heights):
            _plot_single_nesting(width, height, bin_i, frame_width)
