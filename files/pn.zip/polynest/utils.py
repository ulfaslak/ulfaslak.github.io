# -*- coding: utf-8 -*-
"""
This module provides various utility functions for polynest.
"""

import pyclipper
from pyclipper import scale_to_clipper as to_clipper
from pyclipper import scale_from_clipper as from_clipper
import numpy as np
from multiprocessing import get_context

import _polynest as _utils


def area(polygon):
    """Compute the area of a polygon.

    Parameters
    ----------
        polygon : list of tuples

    Returns
    -------
        out : float
    """
    return _utils.area(polygon)


def total_area(polygons):
    """Compute the summed area of a list of polygons.

    Parameters
    ----------
        polygons : list of lists of tuples

    Returns
    -------
        out : float
    """
    return sum(map(_utils.area, polygons))


def dist(point_a, point_b):
    """Compute the euclidian distance between two points.

    Parameters
    ----------
        point_a, point_b : np.array, shape=(2, )

    Returns
    -------
        out : float
    """
    return np.sqrt(sum((point_b - point_a) ** 2))


def flatten(arr):
    """Flatten a list of lists.

    Parameters
    ----------
        arr : list of lists

    Returns
    -------
        out : list
    """
    return [v for arr_inner in arr for v in arr_inner]


def seed_rng(seed, k=0):
    """Seed NumPy's random number generator.

    Meant to handle operations like `None + 1` gracefully.

    Parameters
    ----------
        seed : int
        k : int
    """
    if seed is None:
        np.random.seed(None)
    else:
        np.random.seed(seed + k)


def random_float(seed, k):
    """Seeded random float.

    `np.random.random()` but seeded with `seed + k`.

    Parameters
    ----------
        seed : int
        k : int
    """
    seed_rng(seed, k)
    return np.random.random()


def random_angle(num_rotations):
    """Given a number of possible rotations, get a random angle.

    Parameters
    ----------
        num_rotations : int

    Returns
    -------
        out : float
    """
    return np.random.randint(num_rotations) * 360 / num_rotations


def get_random_pair(arr, p, p_map=lambda x: x):
    """Randomly select two items from `arr` given probabilities `p`.

    Parameters
    ----------
        arr : array-like
        p : array-like
        p_map : function

    Returns
    -------
        out : list of two items from `arr`
    """
    p = p_map(np.array(p))
    p = p / np.sum(p)
    i0, i1 = np.random.choice(list(range(len(arr))), size=2, replace=False, p=p)
    return arr[i0], arr[i1]


def get_random_pair_stallion(arr, p, p_map=lambda x: x):
    """Randomly select two items from `arr` given probabilities `p`.

    Parameters
    ----------
        arr : array-like
        p : array-like
        p_map : function

    Returns
    -------
        out : list of two items from `arr`
    """
    p = p_map(np.array(p))
    p = p / np.sum(p)
    return arr[0], get_random_item(arr[1:], p[1:], p_map)


def get_random_item(arr, p, p_map=lambda x: x):
    """Randomly select an item from `arr` given probabilities `p`.

    Parameters
    ----------
        arr : array-like
        p : array-like
        p_map : function

    Returns
    -------
        out : item from `arr`
    """
    p = p_map(np.array(p))
    p = p / np.sum(p)
    return arr[np.random.choice(list(range(len(arr))), p=p)]


def to_inv_probadist(x):
    """Transform array of values to a probability distribution where small
    values are more likely than large values.

    Parameters
    ----------
        x : array of floats

    Returns
    -------
        x : array of floats (sums to one)
    """
    x = 1 / x
    x -= min(x)
    x /= sum(x)
    return x


def sort_lists_wrt_one(lists, i):
    """Sort multiple lists wrt. one of them.

    Parameters
    ----------
        lists : list of lists
            `lists` should have same length.
        i : int
            Index of list in `lists` to sort wrt.

    Returns
    -------
        out : list of lists
    """
    return list(map(list, zip(*sorted(zip(*lists), key=lambda ab: ab[i]))))


def make_points_tuples(polygon):
    """Convert points in a polygon to tuples.

    Parameters
    ----------
        polygon : list of lists

    Returns
    -------
        out : list of tuples
    """
    return [tuple(p) for p in polygon]


def almost_equal(a, b, tolerance=1e-9):
    """Check if difference between two numbers is less than `tolerance`.

    Parameters
    ----------
        a, b : number
        tolerance : number

    Returns
    -------
        out : bool
    """
    return abs(a - b) < tolerance


def plane_min(x, direction):
    """Get the `direction` most point in a collection of points.

    Parameters
    ----------
        x : array-like (N, 2)
        direction : str
            One of "left", "right", "down", "up"

    Returns
    -------
        out : array-like (2,)
    """
    if direction == "left":
        return x[x[:, 0].argmin()]
    if direction == "right":
        return x[x[:, 0].argmax()]
    if direction == "down":
        return x[x[:, 1].argmin()]
    if direction == "up":
        return x[x[:, 1].argmax()]


def plane_length(x, direction, bin):
    """Get the extent in `direction` of a collection of points.

    Parameters
    ----------
        x : array-like (N, 2)
        direction : str
        bin : tuple

    Returns
    -------
        out : number
    """
    if direction == "left":
        return x[:, 0].max()
    if direction == "right":
        return bin[0] - x[:, 0].min()
    if direction == "down":
        return x[:, 1].max()
    if direction == "up":
        return bin[1] - x[:, 1].min()


def create_bin_polygon(dims):
    """Create a bin polygon, given bin dimensions.

    Parameters
    ----------
        dims : tuple

    Returns
    -------
        out : list of tuples
    """
    return to_clipper([(dims[0], 0), (0, 0), (0, dims[1]), (dims[0], dims[1])])


def similar_enough(polygon_a, polygon_b, pct_thr):
    """Calculate the ratio between the intersection area and area of each.

    Parameters
    ----------
        polygon_a, polygon_b : list of lists of lists
        pct_thr : float (0 < pct_thr <= 1)
            The fractional size of the intersection compared to `polygon_a`.

    Returns
    -------
        out : bool
    """
    intersection = polygon_intersection(polygon_a, polygon_b)

    intersection_area = sum(abs(_utils.area(part)) for part in intersection)
    largest_polygon_area = max(abs(_utils.area(polygon_a)), abs(_utils.area(polygon_b)))

    return intersection_area / largest_polygon_area >= pct_thr


def get_polygon_set(polygons, params):
    """Get list of unique polygons in Clipper coordinates and an index remapping.

    Parameters
    ----------
        polygons : list of lists of lists

    Returns
    -------
        polygon_set : list
        index_map : dict
    """

    def __subtract_min(polygon):
        return np.array(polygon) - np.min(polygon, axis=0)

    def __get_index(polygon_set, polygon_i):
        for iu, polygon_u in enumerate(polygon_set):
            if similar_enough(polygon_u, polygon_i, params["merge_similarity_threshold"]):
                return iu
        else:
            return len(polygon_set)

    def __process(polygon):
        polygon = offset_polygon(polygon, params["part_spacing"], params["curve_tolerance"])
        polygon = wind_clockwise([polygon])[0]
        polygon = clean_polygons([polygon], params["curve_tolerance"])[0]
        return polygon

    def __diff(p0, p1):
        return np.array(p1) - np.array(p0)

    # Instantiate output variables
    polygon_set = []
    index_map = {}

    # Loop through polygons
    for i, polygon in enumerate(polygons):

        # Convert to clipper coordinates
        polygon = to_clipper(polygon)

        # Move to coordinate system origin
        polygon0 = __subtract_min(polygon)

        # Find existing polygon that matches
        set_index = __get_index(polygon_set, polygon0)

        # If none were find, add current polygon to `polygon_set`
        if set_index == len(polygon_set):
            polygon_set.append(__process(polygon0))

        set_polygon = polygon_set[set_index]

        index_map[i] = dict(
            u=set_index,
            d=from_clipper(__diff(polygon0[0], polygon[0])),
            d_anchor=from_clipper(__diff(set_polygon[0], polygon0[0])),
            area=_utils.area(from_clipper(set_polygon)),
        )

    return polygon_set, index_map


def offset_polygon(polygon, offset, curve_tolerance):
    """Offset single polygon by certain amount.

    Parameters
    ----------
        polygon : list of lists
        offset : number
        curve_tolerance : number

    Returns
    -------
        polygon : list of lists
    """
    pco = pyclipper.PyclipperOffset(2, to_clipper(curve_tolerance))
    pco.AddPath(polygon, pyclipper.JT_ROUND, pyclipper.ET_CLOSEDPOLYGON)
    return pco.Execute(to_clipper(offset))[0]


def offset_polygons(polygons, offset, curve_tolerance):
    """Offset list of polygons by certain amount.

    Parameters
    ----------
        polygons : list of lists of lists
        offset : number

    Returns
    -------
        polygons : list of lists of lists
    """
    if offset == 0:
        return polygons
    return [offset_polygon(polygon) for polygon in polygons]


def wind_clockwise(polygons, clockwise=1):
    """Take any non-clockwise polygons and wind them clockwise.

    Parameters
    ----------
        polygons : list of lists of lists
        clockwist : int
            Set to -1 to obtain counter-clockwise winding

    Returns
    -------
        polygons : list of lists of lists
    """
    return [
        polygon[::-1] if _utils.area(polygon) * clockwise < 0 else polygon for polygon in polygons
    ]


def clean_polygons(polygons, curve_tolerance):
    """Apply `CleanPolygons` to polygon set.

    Source: http://www.angusj.com/delphi/clipper/documentation/Docs/Units/ClipperLib/Functions/CleanPolygons.htm

    Parameters
    ----------
        polygons : list of lists of lists
        curve_tolerance : float

    Returns
    -------
        polygons : list of lists of lists
    """
    return pyclipper.CleanPolygons(polygons, to_clipper(curve_tolerance))


def minkowski_diff(inp):
    """Minkowski difference, corresponding to the NFP of `pattern` on `path`.

    Parameters
    ----------
        inp : `key`, (`path`, `pattern`)
            key : tuple of tuples
            path : list of lists
            pattern : list of lists (np.array)
    """
    key, (path, pattern) = inp
    nfps = pyclipper.MinkowskiSum(path, -pattern, True)
    nfps = wind_clockwise(nfps)
    optfunc = min if key[0][0] == -1 else max
    nfp = optfunc(nfps, key=lambda nfp: _utils.area(nfp))
    return key, np.array(nfp) + pattern[0]


def polygon_union(polygons):
    """Get union of polygon set.

    Parameters
    ----------
        polygons : list of lists of lists

    Returns
    -------
        out : list of lists of lists
    """
    pc = pyclipper.Pyclipper()
    pc.AddPaths(polygons, pyclipper.PT_CLIP, True)
    return pc.Execute(pyclipper.CT_UNION, pyclipper.PFT_NONZERO, pyclipper.PFT_NONZERO)


def polygon_intersection(polygon_a, polygon_b):
    """Get union of polygon set.

    Parameters
    ----------
        polygon_a, polygon_b : list of lists of lists

    Returns
    -------
        out : list of lists of lists
    """
    pc = pyclipper.Pyclipper()
    pc.AddPath(polygon_a, pyclipper.PT_SUBJECT, True)
    pc.AddPath(polygon_b, pyclipper.PT_CLIP, True)
    return pc.Execute(pyclipper.CT_INTERSECTION, pyclipper.PFT_EVENODD, pyclipper.PFT_EVENODD)


def polygon_set_difference(polygon_set_a, polygon_set_b):
    """Subtract one set of polygons (a) from another set (b).

    Parameters
    ----------
        polygon_set_a, polygon_set_b : list of lists of lists

    Returns
    -------
        out : list of lists
    """
    pc = pyclipper.Pyclipper()
    pc.AddPaths(polygon_set_a, pyclipper.PT_CLIP, True)
    pc.AddPaths(polygon_set_b, pyclipper.PT_SUBJECT, True)
    return pc.Execute(pyclipper.CT_DIFFERENCE, pyclipper.PFT_NONZERO, pyclipper.PFT_NONZERO)
