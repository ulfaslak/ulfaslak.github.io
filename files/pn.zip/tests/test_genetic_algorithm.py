import polynest

def test_cross_breed():
    # Function
    func = polynest.genetic_algorithm.cross_breed

    # Params and returns
    params = dict(
        pair=[
            {
                'order': [(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0)],
                'rotation': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
            },
            {
                'order': [(5, 0), (4, 0), (3, 0), (2, 0), (1, 0), (0, 0)],
                'rotation': [180.0, 180.0, 180.0, 180.0, 180.0, 180.0]
            }
        ],
        cross_point=0.5,
    )
    returns = [
        {
            'order': [(0, 0), (1, 0), (2, 0), (5, 0), (4, 0), (3, 0)],
            'rotation': [0.0, 0.0, 0.0, 180.0, 180.0, 180.0]
        },
        {
            'order': [(5, 0), (4, 0), (3, 0), (0, 0), (1, 0), (2, 0)],
            'rotation': [180.0, 180.0, 180.0, 0.0, 0.0, 0.0]
        }
    ]

    # Test
    assert str(func(**params)) == str(returns)

def test_mutate():
    # Function
    func = polynest.genetic_algorithm.mutate

    # Params and returns
    params = dict(
        specimen={
            'order': [(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0)],
            'rotation': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        },
        params = dict(
            seed=5,
            GA_mutation_rate=0.1,
            order_indices=[0, 0, 0, 1, 1, 1],
            allow_order_swaps=True,
            num_rotations=2
        )
    )
    returns = {
        'order': [(3, 0), (5, 0), (4, 0), (0, 0), (1, 0), (2, 0)],
        'rotation': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }

    # Test
    assert str(func(**params)) == str(returns)