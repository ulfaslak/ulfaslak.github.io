import polynest

from pyclipper import scale_to_clipper
import numpy as np


def test___init_placement_order():
    # Function
    cls = polynest.Nest()
    func = cls._Nest__init_placement_order

    # Init
    cls.polygons = [
        [(1.0, 0.0), (0.0, 0.0), (0.0, 1.0), (1.0, 1.0)],
        [(2.0, 0.0), (0.0, 0.0), (0.0, 2.0), (2.0, 2.0)],
        [(3.0, 0.0), (0.0, 0.0), (0.0, 3.0), (3.0, 3.0)],
        [(4.0, 0.0), (0.0, 0.0), (0.0, 4.0), (4.0, 4.0)],
    ]
    cls.order_indices = [0, 0, 1, 1]
    cls.quantity = [1, 2, 1, 2]
    cls.n_polygons = sum(cls.quantity)
    cls.polygon_set = scale_to_clipper(cls.polygons)
    cls.index_map = {
        0: {"u": 0, "d": np.array([0.0, 0.0])},
        1: {"u": 1, "d": np.array([0.0, 0.0])},
        2: {"u": 2, "d": np.array([0.0, 0.0])},
        3: {"u": 3, "d": np.array([0.0, 0.0])},
    }
    cls.params = dict(
        num_rotations=2
    )
    cls.seed = 1337

    # Params and returns
    params = dict()
    returns = {
        "order": [(1, 0), (1, 1), (0, 0), (3, 0), (3, 1), (2, 0)],
        "rotation": [180.0, 0.0, 180.0, 180.0, 0.0, 0.0],
    }

    # Test
    assert str(func(**params)) == str(returns)


def test_place_polygons():
    # Function
    cls = polynest.NestRectangular(num_rotations=2, seed=1337)
    func = cls.place_polygons

    # Init
    polygons = [
        [(0.0, 0.0), (0.0, 1.0), (1.0, 1.0), (1.0, 0.0)],
        [(1.0, 1.0), (1.0, 2.0), (2.0, 2.0), (2.0, 1.0)],
        [(-1.0, -1.0), (-1.0, -2.0), (-2.0, -2.0), (-2.0, -1.0)],
        [(3.0, 3.0), (3.0, 4.0), (4.0, 3.0)],
    ]
    bin = (3, 3)
    cls.init_conditions(polygons, bin, None, None)

    # Params and returns
    params = dict(placement_order=cls.best_placement_order)
    returns = (
        [
            {
                "d": [1.0, 3.0],
                "d_clipper": [2147483648.0, 6442450944.0],
                "i": 0,
                "iu": 0,
                "key": (0, 180.0),
                "r": 180.0,
            },
            {
                "d": [-1.0, 0.0],
                "d_clipper": [0.0, 2147483648.0],
                "i": 1,
                "iu": 0,
                "key": (0, 0.0),
                "r": 0.0,
            },
            {
                "d": [4.0, 5.0],
                "d_clipper": [4294967296.0, 6442450944.0],
                "i": 2,
                "iu": 0,
                "key": (0, 180.0),
                "r": 180.0,
            },
            {
                "d": [-1.0, -1.0],
                "d_clipper": [4294967296.0, 4294967296.0],
                "i": 3,
                "iu": 1,
                "key": (1, 180.0),
                "r": 180.0,
            },
        ],
        2.0,
    )

    # Test
    assert str(func(**params)) == str(returns)
