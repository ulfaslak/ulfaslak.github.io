from polynest import utils

import numpy as np
from pyclipper import scale_to_clipper


def test_make_points_tuples():
    # Function
    func = utils.make_points_tuples

    # Params and returns
    params = dict(polygon=[[1, 1], [1, 2], [1, 3], [1, 4]])
    returns = [(1, 1), (1, 2), (1, 3), (1, 4)]

    # Test
    assert func(**params) == returns


def test_get_polygon_set():
    # Function
    func = utils.get_polygon_set

    # Params and returns
    params = dict(
        polygons=[
            [(0, 0), (0, 1), (1, 1), (1, 0)],
            [(0, 0), (0, 1), (1, 0)],
            [(1, 1), (1, 2), (2, 2), (2, 1)],
            [(1, 1), (1, 2), (2, 1)],
            [(2, 2), (2, 3), (3, 3), (3, 2)],
            [(2, 2), (2, 3), (3, 2)],
        ],
        merge_similarity_threshold=0.999,
    )

    returns = (
        [
            np.array([[0, 0], [0, 1], [1, 1], [1, 0]]),
            np.array([[0, 0], [0, 1], [1, 0]]),
        ],
        {
            0: {"u": 0, "d": np.array([0, 0])},
            1: {"u": 1, "d": np.array([0, 0])},
            2: {"u": 0, "d": np.array([1, 1])},
            3: {"u": 1, "d": np.array([1, 1])},
            4: {"u": 0, "d": np.array([2, 2])},
            5: {"u": 1, "d": np.array([2, 2])},
        },
    )

    # Test
    str(func(**params)) == str(returns)


def test_offset_polygons():
    # Function
    func = utils.offset_polygons

    # Params and returns
    params = dict(
        polygons=scale_to_clipper([[(1, 1), (0, 1), (0, 0), (1, 0)]]),
        offset=1,
        curve_tolerance=0.3,
    )
    returns = scale_to_clipper(
        [[(2, 0), (2, 1), (1, 2), (0, 2), (-1, 1), (-1, 0), (0, -1), (1, -1)]]
    )

    # Test
    assert func(**params) == returns


def test_wind_clockwise():
    # Function
    func = utils.wind_clockwise

    # Params and returns
    params = dict(polygons=[[(1, 1), (0, 1), (0, 0), (1, 0)]])
    returns = [[(1, 0), (0, 0), (0, 1), (1, 1)]]

    # Test
    assert func(**params) == returns


def test_minkowski_diff():
    # Function
    func = utils.minkowski_diff

    # Params and returns
    params = dict(
        inp=(
            "my_key",
            (
                np.array(scale_to_clipper([(2, 0), (0, 0), (0, 2), (2, 2)])),
                np.array(scale_to_clipper([(1, 0), (0, 0), (0, 1), (1, 1)])),
            ),
        )
    )
    returns = ("my_key", np.array(scale_to_clipper([[3, 2], [3, -1], [0, -1], [0, 2]])))

    # Test
    assert str(func(**params)) == str(returns)
