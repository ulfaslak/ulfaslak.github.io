import _polynest as _

import numpy as np


def test_area():
    # Function
    func = _.area

    # Params and returns
    params = dict(polygon=[[1, 0], [0, 0], [0, 1], [1, 1]])
    returns = 1

    # Test
    assert func(**params) == returns


def test_rotate_polygon():
    # Function
    func = _.rotate_polygon

    # Params and returns
    params = dict(polygon=[(1, 0), (0, 0), (0, 1), (1, 1)], degrees=180, rotate_wrt_own_bbox=True)
    returns = [(-1, 0), (0, 0), (0, -1), (-1, -1)]

    # Test
    out = func(**params)
    assert np.max(abs(np.array(returns) - np.array(out))) < 1e-6
