#include <iostream>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/numpy.h>

#include "Geometry.h"

using namespace std;
namespace py = pybind11;

PYBIND11_MODULE(_polynest, m)
{
    m.doc() = R"pbdoc(
	    Polynest C++ plugin
	    -------------------
	    .. currentmodule:: polynest
	    .. autosummary::
	       :toctree: _generate
	       identity
	)pbdoc";

	m.def(
		"area",
		&area,
		R"pbdoc(
		Compute the area of a polygon
	
		Parameters
		----------
			polygon : list of lists
		
		Returns
		-------
			float
    	)pbdoc",
		py::arg("polygon")
	);

	m.def(
		"rotate_polygon",
		&rotate_polygon,
		R"pbdoc(
		Rotate a polygon by a given degree
	
		Parameters
		----------
			polygon : list of lists
			degree : number
			rotate_wrt_own_bbox : bool
				Whether to rotate the polygon around its own bounding box' top left point
				or around the coordinate system origin.
		
		Returns
		-------
			rotated_polygon : list of lists
    	)pbdoc",
		py::arg("polygon"),
		py::arg("degrees"),
		py::arg("rotate_wrt_own_bbox")
	);

	m.def(
		"rotate_point",
		&rotate_point,
		R"pbdoc(
		Rotate a point by a given degree around the origin
	
		Parameters
		----------
			polygon : list of lists
			degree : number
		
		Returns
		-------
			rotated_polygon : list of lists
    	)pbdoc",
		py::arg("polygon"),
		py::arg("degrees")
	);

	m.def(
		"point_inside_polygons",
		&point_inside_polygons,
		R"pbdoc(
		Check if a point is inside any polygon in list of polygons
	
		Parameters
		----------
			p : tuple
			polygon : list of lists of lists
		
		Returns
		-------
			inside : bool
    	)pbdoc",
		py::arg("p"),
		py::arg("polygons")
	);

	m.def(
		"find_nearest",
		&find_nearest,
		R"pbdoc(
		Find index of point in `polygon` nearest to `p`.
	
		Parameters
		----------
			p : tuple
			polygon : list of lists
		
		Returns
		-------
			inside : float
    	)pbdoc",
		py::arg("p"),
		py::arg("polygons"),
		py::arg("block_i")
	);
}
