#ifndef __GEOMETRY__
#define __GEOMETRY__

#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>

using namespace std;

double area(vector<vector<double>> &polygon);

vector<tuple<double, double>> rotate_polygon(vector<tuple<double, double>> polygon, double degrees, bool rotate_wrt_own_bbox);

tuple<double, double> rotate_point(tuple<double, double> point, double degrees);

bool point_inside_polygon(tuple<double, double> p, vector<tuple<double, double>> polygon);

bool point_inside_polygons(tuple<double, double> p, vector<vector<tuple<double, double>>> polygons);

double euclidan_distance(tuple<double, double> p1, tuple<double, double> p2);

tuple<int, int> find_nearest(tuple<double, double> p, vector<vector<tuple<double, double>>> polygons, int block_i);

#endif