#include "Geometry.h"

using namespace std;

double area(vector<vector<double>> &polygon)
{
    int n = polygon.size();
    double area = 0.0;
    int j = n - 1;

    for (int i = 0; i < n; i++)
    {
        area += (polygon[j][0] + polygon[i][0]) * (polygon[j][1] - polygon[i][1]);
        j = i;
    }

    return area / 2;
};

vector<tuple<double, double>> rotate_polygon(vector<tuple<double, double>> polygon, double degrees, bool rotate_wrt_own_bbox)
{
    double x;
    double y;
    double x1;
    double y1;

    double x_min = INFINITY,
           y_min = INFINITY;

    int N = polygon.size();
    double angle = degrees * M_PI / 180;

    if (rotate_wrt_own_bbox)
    {
        for (int i = 0; i < N; i++)
        {
            x = get<0>(polygon[i]);
            y = get<1>(polygon[i]);

            if (x < x_min)
            {
                x_min = x;
            }
            if (y < y_min)
            {
                y_min = y;
            }
        }
    } else
    {
        x_min = 0;
        y_min = 0;
    }

    vector<tuple<double, double>> rotated_polygon(N);
    for (int i = 0; i < N; i++)
    {
        x = get<0>(polygon[i]) - x_min;
        y = get<1>(polygon[i]) - y_min;
        x1 = x * cos(angle) - y * sin(angle) + x_min;
        y1 = x * sin(angle) + y * cos(angle) + y_min;
        rotated_polygon[i] = make_tuple(x1, y1);
    }

    return rotated_polygon;
};

tuple<double, double> rotate_point(tuple<double, double> point, double degrees)
{
    double angle = degrees * M_PI / 180;

    double x = get<0>(point);
    double y = get<1>(point);
    double x1 = x * cos(angle) - y * sin(angle);
    double y1 = x * sin(angle) + y * cos(angle);

    return make_tuple(x1, y1);
};

bool point_inside_polygon(tuple<double, double> p, vector<tuple<double, double>> polygon)
{
    auto [x, y] = p;
    int N = polygon.size();
    bool inside = false;
    double xinters;

    auto [p1x, p1y] = polygon[0];

    for (int i = 0; i < N + 1; i++)
    {
        auto [p2x, p2y] = polygon[i % N];
        if (y > min(p1y, p2y))
        {
            if (y < max(p1y, p2y))
            {
                if (x <= max(p1x, p2x))
                {
                    if (p1y != p2y)
                    {
                        xinters = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x;
                    }
                    if (p1x == p2x || x <= xinters)
                    {
                        inside = not inside;
                    }
                }
            }
        }
        p1x = p2x;
        p1y = p2y;
    }
    return inside;
};

bool point_inside_polygons(tuple<double, double> p, vector<vector<tuple<double, double>>> polygons)
{
    for (size_t i = 0; i < polygons.size(); i++)
    {
        if (point_inside_polygon(p, polygons[i])){
            return true;
        }
    }
    return false;
}

double euclidan_distance(tuple<double, double> p1, tuple<double, double> p2)
{
    auto [x1, y1] = p1;
    auto [x2, y2] = p2;
    return sqrt(pow(x1 - x2, 2) + pow(y1 - y2, 2));
}

tuple<int, int> find_nearest(tuple<double, double> p, vector<vector<tuple<double, double>>> polygons, int block_i)
{
    int N = polygons.size();

    int i_min, j_min;
    double min_dist = INFINITY;
    double distance;
    for (int i = 0; i < N; i++)
    {
        int M = polygons[i].size();
        for (int j = 0; j < M; j++)
        {
            distance = euclidan_distance(p, polygons[i][j]);
            if (distance < min_dist && i != block_i) {
                min_dist = distance;
                i_min = i;
                j_min = j;
            }
        }
    }

    return make_tuple(i_min, j_min);
}