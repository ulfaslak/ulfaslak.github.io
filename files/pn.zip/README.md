# `polynest`
> Python package for fast and versatile polygon nesting

[![Build Status][build-image]][build-url]

## Usage

The `polynest` API follows the standard pattern of popular modeling frameworks such as `sklearn`:

```Python
from polynest import NestRectangular
model = NestRectangular()
model.fit(polygons, bin_dimensions)
```

Once a model has been fitted, the best placement of `polygons` within the `bin_dimensions` can be retrieved:

```Python
translations = model.best_translations
```

`polynest` also includes simple plotting tools.

```Python
from polynest.visualization import plot_nesting
plot_nesting(model, frame_width=10, color="black")
```
![](img/nesting_example.png)


## Install

To install the package, clone it, navigate into the `polynest` folder and execute `make install`.
Alternatively, install using pip. This is done by executing `git+https://<token>@github.com/Rodinia-Generation/polynest.git` where `<token>` is a personal access token that you must obtain from Ulf Aslak (for the time being).


## Development

It is recommended that developers use a virtual environment, when contributing to `polynest`.

**Instructions for getting started**:

1. Create a virtual environment and activate it
```Bash
$ pip install virtualenv   # if you do not have it installed already
$ virtualenv env           # create
$ source env/bin/activate  # activate
```

2. Install `polynest`
```Bash
(env) $ make install
```

**Convenient things**:

3. Create a Jupyter kernel with the virtual environment

If you like to test and develop code using Jupyter notebooks, you can install the virtual environment into Jupyter as a kernel.
This lets you select the virtual environment as a kernel in a Jupyter notebook (e.g. the one inside `notebooks` folder).
```Bash
(env) $ pip install ipykernel  # install ipykernel into `env`
(env) $ python -m ipykernel install --user --name=polynest_env   # install `env` as a kernel into 
```

4. Run test scripts:
```Bash
(env) $ make test
```
5. Check test coverage:
```Bash
(env) $ make coverage               # build the coverage report
(env) $ cd htmlcov                  # access the easy-to-read html coverage report 
(env) $ python -m http.server 8001  # launch it. go to localhost:8001 in your browser
```


<!-- Badges -->

[build-image]: https://github.com/Rodinia-generation/polynest/actions/workflows/build.yml/badge.svg
[build-url]: https://github.com/Rodinia-generation/polynest/actions/workflows/build.yml
